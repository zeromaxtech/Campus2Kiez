import React, { useState } from 'react';
import { Upload, CheckCircle, AlertTriangle, Loader2, Fingerprint } from 'lucide-react';
import { validateOfferLetter } from '../services/geminiService';
import { uploadFileToStorage } from '../services/firebase';
import { VerificationResult } from '../types';

interface OfferValidatorProps {
  passportLast4: string;
  onSuccess: () => void;
}

export const OfferValidator: React.FC<OfferValidatorProps> = ({ passportLast4, onSuccess }) => {
  const [offerFile, setOfferFile] = useState<File | null>(null);
  const [passportFile, setPassportFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(null);

  const handleOfferChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setOfferFile(e.target.files[0]);
    }
  };

  const handlePassportChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setPassportFile(e.target.files[0]);
    }
  };

  const handleVerify = async () => {
    if (!offerFile || !passportFile) return;
    setLoading(true);
    setResult(null);
    try {
      // 1. Upload to Firebase
      await uploadFileToStorage(offerFile, passportLast4, 'offer_letter');
      await uploadFileToStorage(passportFile, passportLast4, 'passport');

      // 2. Process with Gemini
      const res = await validateOfferLetter(offerFile, passportFile);
      setResult(res);
      if (res.isValid) {
        // Optional: Trigger success callback after delay
        // setTimeout(onSuccess, 3000); 
      }
    } catch (e) {
      console.error(e);
      alert("Verification failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 animate-fade-in">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Step 1: Document Verification</h2>
        <p className="text-slate-600">
          Upload your University Offer Letter and Passport Copy. We will cross-reference your identity and generate a unique student hash.
        </p>
      </div>

      <div className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
            {/* Offer Letter Upload */}
            <div className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${offerFile ? 'border-indigo-500 bg-indigo-50' : 'border-slate-300 hover:border-indigo-400'}`}>
              <input
                type="file"
                id="offer-letter"
                accept=".pdf,.jpg,.jpeg,.png"
                className="hidden"
                onChange={handleOfferChange}
              />
              <label htmlFor="offer-letter" className="cursor-pointer flex flex-col items-center">
                <Upload className="w-8 h-8 text-slate-400 mb-3" />
                <span className="text-sm font-medium text-slate-700">
                  {offerFile ? offerFile.name : "Upload Offer Letter"}
                </span>
                <span className="text-xs text-slate-500 mt-1">PDF or Image</span>
              </label>
            </div>

            {/* Passport Upload */}
            <div className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${passportFile ? 'border-indigo-500 bg-indigo-50' : 'border-slate-300 hover:border-indigo-400'}`}>
              <input
                type="file"
                id="passport-file"
                accept=".jpg,.jpeg,.png,.pdf"
                className="hidden"
                onChange={handlePassportChange}
              />
              <label htmlFor="passport-file" className="cursor-pointer flex flex-col items-center">
                <Fingerprint className="w-8 h-8 text-slate-400 mb-3" />
                <span className="text-sm font-medium text-slate-700">
                  {passportFile ? passportFile.name : "Upload Passport Copy"}
                </span>
                <span className="text-xs text-slate-500 mt-1">Image or PDF</span>
              </label>
            </div>
        </div>

        {/* Action Button */}
        <button
          onClick={handleVerify}
          disabled={!offerFile || !passportFile || loading}
          className={`w-full py-4 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-all ${
            !offerFile || !passportFile || loading
              ? 'bg-slate-200 text-slate-500 cursor-not-allowed'
              : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md hover:shadow-lg'
          }`}
        >
          {loading ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Securing & Verifying...</span>
            </>
          ) : (
            <>
              <CheckCircle className="w-5 h-5" />
              <span>Verify & Generate Hash</span>
            </>
          )}
        </button>

        {/* Results */}
        {result && (
          <div className={`mt-6 p-6 rounded-lg border-l-4 ${result.isValid ? 'bg-green-50 border-green-500' : 'bg-red-50 border-red-500'}`}>
            <div className="flex items-start space-x-3">
              {result.isValid ? (
                <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0" />
              ) : (
                <AlertTriangle className="w-6 h-6 text-red-600 flex-shrink-0" />
              )}
              <div className="space-y-3 w-full">
                <div className="flex justify-between items-start">
                    <h3 className={`font-bold ${result.isValid ? 'text-green-800' : 'text-red-800'}`}>
                    {result.isValid ? "Identity Verified" : "Verification Failed"}
                    </h3>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {result.universityName && (
                    <div className="bg-white/60 p-2 rounded">
                        <span className="text-xs text-slate-500 block">University</span>
                        <span className="text-sm font-medium text-slate-800">{result.universityName}</span>
                    </div>
                    )}
                     {result.studentName && (
                    <div className="bg-white/60 p-2 rounded">
                        <span className="text-xs text-slate-500 block">Student Name</span>
                        <span className="text-sm font-medium text-slate-800">{result.studentName}</span>
                    </div>
                    )}
                </div>

                {result.studentHash && (
                    <div className="bg-indigo-100 border border-indigo-200 p-3 rounded-md flex items-center justify-between">
                        <div>
                            <span className="text-xs text-indigo-600 uppercase font-bold tracking-wider">Embassy Student Hash</span>
                            <div className="font-mono text-lg font-bold text-indigo-900 tracking-wide">{result.studentHash}</div>
                        </div>
                        <Fingerprint className="w-6 h-6 text-indigo-400" />
                    </div>
                )}

                 <div className="mt-2 text-sm bg-white/50 p-3 rounded border border-black/5">
                    <p className="font-semibold text-xs uppercase tracking-wide opacity-70 mb-1">Reasoning Trace:</p>
                    <p className="text-slate-800 leading-relaxed text-xs">{result.reasoning}</p>
                 </div>
                 
                 {result.isValid && (
                   <button onClick={onSuccess} className="mt-4 px-4 py-2 bg-green-600 text-white text-sm font-medium rounded hover:bg-green-700">
                     Proceed to APS & Visa
                   </button>
                 )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};