import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Volume2, AlertCircle, Radio } from 'lucide-react';
import { createLiveSession } from '../services/geminiService';

export const LiveTranslator: React.FC = () => {
  const [active, setActive] = useState(false);
  const [status, setStatus] = useState('Disconnected');
  const [error, setError] = useState('');
  
  // Audio Context Refs
  const inputContextRef = useRef<AudioContext | null>(null);
  const outputContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const sessionRef = useRef<any>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  // Helper to decode audio
  const decodeAudio = async (base64: string, ctx: AudioContext) => {
    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
    }
    
    // Convert PCM to AudioBuffer
    const float32Data = new Float32Array(bytes.length / 2);
    const dataView = new DataView(bytes.buffer);
    
    for (let i = 0; i < bytes.length / 2; i++) {
      float32Data[i] = dataView.getInt16(i * 2, true) / 32768.0;
    }

    const buffer = ctx.createBuffer(1, float32Data.length, 24000);
    buffer.getChannelData(0).set(float32Data);
    return buffer;
  };

  const startSession = async () => {
    setError('');
    setStatus('Connecting...');
    
    try {
        // 1. Setup Audio Inputs
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        streamRef.current = stream;
        
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        inputContextRef.current = new AudioContextClass({ sampleRate: 16000 });
        outputContextRef.current = new AudioContextClass({ sampleRate: 24000 });

        // 2. Connect to Live API
        const sessionPromise = createLiveSession(
            () => setStatus('Live Agent Active'),
            async (msg) => {
                // Handle Audio Output
                const base64Audio = msg.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
                if (base64Audio && outputContextRef.current) {
                    const ctx = outputContextRef.current;
                    const buffer = await decodeAudio(base64Audio, ctx);
                    
                    const source = ctx.createBufferSource();
                    source.buffer = buffer;
                    source.connect(ctx.destination);
                    
                    const startTime = Math.max(nextStartTimeRef.current, ctx.currentTime);
                    source.start(startTime);
                    nextStartTimeRef.current = startTime + buffer.duration;
                    
                    sourcesRef.current.add(source);
                    source.onended = () => sourcesRef.current.delete(source);
                }
            },
            (e) => {
                console.error("Live Error", e);
                setError("Connection Error");
                setActive(false);
            },
            () => {
                setStatus('Disconnected');
                setActive(false);
            }
        );

        sessionRef.current = sessionPromise;

        // 3. Stream Input Audio
        const source = inputContextRef.current.createMediaStreamSource(stream);
        const processor = inputContextRef.current.createScriptProcessor(4096, 1, 1);
        
        processor.onaudioprocess = (e) => {
            const inputData = e.inputBuffer.getChannelData(0);
            
            // Convert Float32 to Int16 PCM Base64
            const pcmInt16 = new Int16Array(inputData.length);
            for (let i = 0; i < inputData.length; i++) {
                pcmInt16[i] = inputData[i] * 0x7FFF;
            }
            
            const uint8 = new Uint8Array(pcmInt16.buffer);
            let binary = '';
            for(let i=0; i<uint8.length; i++) binary += String.fromCharCode(uint8[i]);
            const base64 = btoa(binary);

            sessionPromise.then(session => {
                session.sendRealtimeInput({
                    media: {
                        mimeType: 'audio/pcm;rate=16000',
                        data: base64
                    }
                });
            });
        };

        source.connect(processor);
        processor.connect(inputContextRef.current.destination);
        
        setActive(true);

    } catch (e) {
        console.error(e);
        setError("Failed to access microphone or connect.");
        setStatus('Error');
    }
  };

  const stopSession = () => {
    setActive(false);
    setStatus('Disconnected');
    
    // Cleanup
    streamRef.current?.getTracks().forEach(t => t.stop());
    inputContextRef.current?.close();
    outputContextRef.current?.close();
    // Assuming session has a close method or handled by garbage collection/disconnect
    // sessionRef.current?.then((s: any) => s.close && s.close()); 
  };

  return (
    <div className="bg-slate-900 text-white rounded-xl shadow-lg border border-slate-700 p-8 animate-fade-in relative overflow-hidden">
       {/* Background Pulse Animation */}
       {active && (
         <div className="absolute top-0 right-0 p-4">
            <span className="relative flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-red-500"></span>
            </span>
         </div>
       )}

      <div className="mb-8 z-10 relative">
        <h2 className="text-2xl font-bold mb-2 flex items-center">
            <Radio className="w-6 h-6 mr-2 text-indigo-400" />
            Live Translator
        </h2>
        <p className="text-slate-400">
          Real-time German ↔ English/Hindi translation for landlord meetings or bureaucracy. 
          Low latency audio streaming active.
        </p>
      </div>

      <div className="flex flex-col items-center justify-center space-y-6 z-10 relative">
        <div className={`w-32 h-32 rounded-full flex items-center justify-center border-4 transition-all duration-500 ${active ? 'border-red-500 bg-red-500/10 shadow-[0_0_40px_rgba(239,68,68,0.5)]' : 'border-slate-600 bg-slate-800'}`}>
             {active ? <Volume2 className="w-12 h-12 text-red-500 animate-pulse" /> : <MicOff className="w-12 h-12 text-slate-500" />}
        </div>

        <div className="text-center">
            <div className="text-xl font-mono font-bold tracking-widest uppercase mb-1">{status}</div>
            {error && <div className="text-red-400 text-sm flex items-center justify-center"><AlertCircle className="w-4 h-4 mr-1"/> {error}</div>}
        </div>

        <button
            onClick={active ? stopSession : startSession}
            className={`px-8 py-3 rounded-full font-bold text-lg transition-all ${
                active 
                ? 'bg-red-600 hover:bg-red-700 text-white shadow-lg' 
                : 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-lg shadow-emerald-500/20'
            }`}
        >
            {active ? "Stop Transmission" : "Activate Live Agent"}
        </button>
      </div>
    </div>
  );
};