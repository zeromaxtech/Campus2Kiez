import React, { useState, useRef } from 'react';
import { Video, ShieldCheck, FileText, Loader2, Play, Camera, StopCircle } from 'lucide-react';
import { analyzeVideoKYC } from '../services/geminiService';
import { uploadFileToStorage } from '../services/firebase';
import { KYCResult } from '../types';

interface VideoKYCProps {
  passportLast4: string;
  onSuccess: () => void;
}

export const VideoKYC: React.FC<VideoKYCProps> = ({ passportLast4, onSuccess }) => {
  const [videoFile, setVideoFile] = useState<File | Blob | null>(null);
  const [contractFile, setContractFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<KYCResult | null>(null);
  
  // Camera State
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  const handleVideoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      setVideoFile(selectedFile);
      setPreviewUrl(URL.createObjectURL(selectedFile));
      setResult(null);
      setIsCameraActive(false);
    }
  };

  const startCamera = async () => {
      try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: true });
          if (videoRef.current) {
              videoRef.current.srcObject = stream;
              videoRef.current.play();
          }
          setIsCameraActive(true);
          setPreviewUrl(null);
      } catch (err) {
          console.error("Camera access denied", err);
          alert("Could not access camera.");
      }
  };

  const startRecording = () => {
      if (!videoRef.current?.srcObject) return;
      
      const stream = videoRef.current.srcObject as MediaStream;
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
          if (e.data.size > 0) chunksRef.current.push(e.data);
      };

      mediaRecorder.onstop = () => {
          const blob = new Blob(chunksRef.current, { type: 'video/webm' });
          const file = new File([blob], "live-kyc-capture.webm", { type: 'video/webm' });
          setVideoFile(file);
          const url = URL.createObjectURL(blob);
          setPreviewUrl(url);
          // Stop stream tracks
          stream.getTracks().forEach(track => track.stop());
          setIsCameraActive(false);
      };

      mediaRecorder.start();
      setIsRecording(true);
  };

  const stopRecording = () => {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
  };

  const handleContractChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
        setContractFile(e.target.files[0]);
    }
  };

  const handleAnalyze = async () => {
    if (!videoFile) return;
    setLoading(true);
    try {
      // 1. Upload to Firebase
      await uploadFileToStorage(videoFile, passportLast4, 'video_kyc');
      if (contractFile) {
        await uploadFileToStorage(contractFile, passportLast4, 'video_kyc'); // Storing contract in same folder for context
      }

      // 2. Gemini Analysis
      const res = await analyzeVideoKYC(videoFile as File, contractFile || undefined);
      setResult(res);
      if (res.verified && res.keyExchanged) {
          // Success state
      }
    } catch (e) {
      console.error(e);
      alert("Video analysis failed. Please ensure the format is supported.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 animate-fade-in">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Step 3: Safe Arrival & Video KYC</h2>
        <p className="text-slate-600">
          Record a live video showing <strong>Your Passport details</strong> and the <strong>Keys</strong> received from the landlord.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <div className="space-y-4">
           {/* Video Area */}
           <div className={`border-2 border-dashed rounded-xl overflow-hidden relative bg-slate-100 h-64 flex flex-col items-center justify-center ${videoFile ? 'border-indigo-500' : 'border-slate-300'}`}>
              
              {isCameraActive ? (
                   <video ref={videoRef} className="w-full h-full object-cover" muted />
              ) : previewUrl ? (
                   <video src={previewUrl} controls className="w-full h-full object-contain" />
              ) : (
                   <div className="text-center p-4">
                       <Video className="w-10 h-10 text-slate-400 mb-2 mx-auto" />
                       <p className="text-slate-500 text-sm">No video selected</p>
                   </div>
              )}

              {/* Camera Controls Overlay */}
              {isCameraActive && (
                  <div className="absolute bottom-4 left-0 right-0 flex justify-center">
                      {isRecording ? (
                          <button onClick={stopRecording} className="bg-red-600 text-white px-4 py-2 rounded-full flex items-center font-bold animate-pulse">
                              <StopCircle className="w-5 h-5 mr-1" /> Stop Recording
                          </button>
                      ) : (
                           <button onClick={startRecording} className="bg-red-500 text-white px-4 py-2 rounded-full flex items-center font-bold hover:bg-red-600">
                              <div className="w-3 h-3 bg-white rounded-full mr-2"></div> Record
                          </button>
                      )}
                  </div>
              )}
           </div>

           <div className="flex gap-2">
               {!isCameraActive && !videoFile && (
                   <button onClick={startCamera} className="flex-1 bg-slate-800 text-white py-2 rounded-lg flex items-center justify-center font-medium hover:bg-slate-700">
                       <Camera className="w-4 h-4 mr-2" /> Start Camera
                   </button>
               )}
               
               <div className="flex-1 relative">
                    <input
                        type="file"
                        id="video-upload"
                        accept="video/mp4,video/quicktime,video/webm"
                        className="hidden"
                        onChange={handleVideoChange}
                    />
                    <label htmlFor="video-upload" className="w-full h-full bg-slate-200 text-slate-700 py-2 rounded-lg flex items-center justify-center font-medium cursor-pointer hover:bg-slate-300">
                        Upload File
                    </label>
               </div>
           </div>

            {/* Contract Upload Area (Optional) */}
            <div className={`border border-dashed rounded-lg p-3 flex items-center justify-between ${contractFile ? 'bg-indigo-50 border-indigo-300' : 'bg-slate-50 border-slate-300'}`}>
                <div className="flex items-center space-x-3">
                    <div className="p-2 bg-white rounded shadow-sm">
                        <FileText className="w-5 h-5 text-indigo-500" />
                    </div>
                    <div className="text-left">
                        <p className="text-sm font-medium text-slate-700">{contractFile ? contractFile.name : "Attach Rental Contract"}</p>
                        <p className="text-xs text-slate-500">{contractFile ? "Attached for verification" : "For landlord verification"}</p>
                    </div>
                </div>
                <input
                    type="file"
                    id="contract-upload-kyc"
                    accept=".pdf,.jpg,.png"
                    className="hidden"
                    onChange={handleContractChange}
                />
                <label htmlFor="contract-upload-kyc" className="text-xs font-semibold text-indigo-600 cursor-pointer hover:underline px-2">
                    {contractFile ? "Change" : "Upload"}
                </label>
            </div>
           
           <button
              onClick={handleAnalyze}
              disabled={!videoFile || loading}
              className={`w-full py-3 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-all ${
                !videoFile || loading
                  ? 'bg-slate-200 text-slate-500 cursor-not-allowed'
                  : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow'
              }`}
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Analyzing Passport & Keys...</span>
                </>
              ) : (
                <>
                  <Play className="w-5 h-5" />
                  <span>Run Security Check</span>
                </>
              )}
            </button>
        </div>

        {/* Results Area */}
        <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
            <h3 className="font-semibold text-slate-900 mb-4 flex items-center">
                <ShieldCheck className="w-5 h-5 mr-2 text-indigo-600" />
                AI Analysis Report
            </h3>
            
            {!result && !loading && (
                <p className="text-sm text-slate-500 italic">Record or upload a video to see the security analysis.</p>
            )}

            {loading && (
                <div className="space-y-3 animate-pulse">
                    <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                    <div className="h-4 bg-slate-200 rounded w-1/2"></div>
                    <div className="h-4 bg-slate-200 rounded w-5/6"></div>
                </div>
            )}

            {result && (
                <div className="space-y-4">
                    <div className={`p-4 rounded-lg border ${result.verified ? 'bg-green-100 border-green-300 text-green-800' : 'bg-red-100 border-red-300 text-red-800'}`}>
                        <div className="font-bold text-lg mb-1">{result.verified ? "Secure Handover Verified" : "Verification Failed"}</div>
                        <div className="text-sm">{result.analysis}</div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="bg-white p-3 rounded border border-slate-200">
                            <span className="text-slate-500 block text-xs uppercase">Key Exchange</span>
                            <span className={`font-semibold ${result.keyExchanged ? 'text-green-600' : 'text-red-600'}`}>
                                {result.keyExchanged ? 'Detected' : 'Not Detected'}
                            </span>
                        </div>
                        <div className="bg-white p-3 rounded border border-slate-200">
                            <span className="text-slate-500 block text-xs uppercase">Landlord</span>
                            <span className="font-semibold text-slate-900">{result.landlordName || "Unknown"}</span>
                        </div>
                    </div>

                    {result.verified && (
                        <div className="bg-blue-50 p-3 rounded border border-blue-200 text-sm text-blue-800">
                            <span className="font-bold">Identity Confirmed.</span> Passport details matched and Keys were exchanged.
                        </div>
                    )}

                    {result.verified && (
                        <button onClick={onSuccess} className="w-full mt-2 bg-green-600 text-white py-2 rounded-lg font-medium hover:bg-green-700 transition-colors">
                            Proceed to Registration
                        </button>
                    )}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};