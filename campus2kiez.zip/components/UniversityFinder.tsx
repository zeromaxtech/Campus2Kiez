import React, { useState, useEffect } from 'react';
import { Search, GraduationCap, ExternalLink, Loader2, ArrowRight, Calculator } from 'lucide-react';
import { searchUniversities } from '../services/geminiService';
import { UniSearchResult } from '../types';

interface UniversityFinderProps {
  onNext: () => void;
}

export const UniversityFinder: React.FC<UniversityFinderProps> = ({ onNext }) => {
  const [field, setField] = useState('Computer Science');
  const [indianCgpa, setIndianCgpa] = useState('8.5');
  const [germanGrade, setGermanGrade] = useState('');
  const [ielts, setIelts] = useState('7.0');
  const [preferredCity, setPreferredCity] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<UniSearchResult[]>([]);

  // Modified Bavarian Formula: G = 1 + 3 * ((10 - CGPA) / (10 - 4))
  // Assuming min passing is 4.0 and max is 10.0
  useEffect(() => {
    const cgpa = parseFloat(indianCgpa);
    if (!isNaN(cgpa) && cgpa >= 4 && cgpa <= 10) {
      const g = 1 + 3 * ((10 - cgpa) / (10 - 4));
      setGermanGrade(g.toFixed(2));
    } else {
      setGermanGrade('Invalid');
    }
  }, [indianCgpa]);

  const handleSearch = async () => {
    setLoading(true);
    setResults([]);
    try {
      // Pass the calculated German grade to the service
      const gradeToSend = germanGrade === 'Invalid' ? '2.5' : germanGrade;
      const data = await searchUniversities(field, gradeToSend, ielts, preferredCity);
      setResults(data);
    } catch (e) {
      console.error(e);
      alert("Failed to fetch universities. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-300 p-8 animate-fade-in text-slate-900">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Step 0: University Agent (DAAD)</h2>
        <p className="text-slate-700 font-medium">
          Find English-taught, Tuition-Free Master programs. Sorted by QS World Rankings 2026.
        </p>
      </div>

      <div className="grid md:grid-cols-4 gap-6 mb-8">
        <div className="md:col-span-1">
          <label className="block text-sm font-bold text-slate-800 uppercase mb-2">Target Field</label>
          <input 
            type="text" 
            value={field}
            onChange={(e) => setField(e.target.value)}
            className="w-full px-4 py-3 rounded-lg border-2 border-slate-400 bg-white text-black font-semibold focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600 outline-none transition-all placeholder-slate-400"
            placeholder="e.g. Data Science"
          />
        </div>
        
        {/* Grade Converter Input */}
        <div className="md:col-span-1 relative">
          <label className="block text-sm font-bold text-slate-800 uppercase mb-2">Indian CGPA (10.0 Scale)</label>
          <input 
            type="number" 
            step="0.1"
            min="4"
            max="10"
            value={indianCgpa}
            onChange={(e) => setIndianCgpa(e.target.value)}
            className="w-full px-4 py-3 rounded-lg border-2 border-slate-400 bg-white text-black font-semibold focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600 outline-none transition-all"
            placeholder="8.5"
          />
          {germanGrade && germanGrade !== 'Invalid' && (
            <div className="absolute -bottom-6 right-0 text-sm font-bold text-indigo-700 flex items-center">
              <Calculator className="w-3 h-3 mr-1" />
              German Grade: {germanGrade}
            </div>
          )}
        </div>

        <div className="md:col-span-1">
          <label className="block text-sm font-bold text-slate-800 uppercase mb-2">IELTS Score</label>
          <input 
            type="number" 
            step="0.5"
            value={ielts}
            onChange={(e) => setIelts(e.target.value)}
            className="w-full px-4 py-3 rounded-lg border-2 border-slate-400 bg-white text-black font-semibold focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600 outline-none transition-all"
            placeholder="0 - 9.0"
          />
        </div>
        <div className="md:col-span-1">
          <label className="block text-sm font-bold text-slate-800 uppercase mb-2">Pref. City (Opt)</label>
          <input 
            type="text" 
            value={preferredCity}
            onChange={(e) => setPreferredCity(e.target.value)}
            className="w-full px-4 py-3 rounded-lg border-2 border-slate-400 bg-white text-black font-semibold focus:ring-2 focus:ring-indigo-600 focus:border-indigo-600 outline-none transition-all"
            placeholder="e.g. Berlin"
          />
        </div>
      </div>

      <button
        onClick={handleSearch}
        disabled={loading}
        className="w-full mb-8 py-4 bg-slate-900 text-white text-lg rounded-lg font-bold flex items-center justify-center space-x-2 hover:bg-slate-800 active:bg-slate-950 transition-all shadow-md"
      >
        {loading ? <Loader2 className="animate-spin w-6 h-6" /> : <Search className="w-6 h-6" />}
        <span>Scan DAAD Database & Sort by Rank</span>
      </button>

      <div className="space-y-4">
        {results.map((uni, idx) => (
          <div key={idx} className="border-2 border-slate-200 rounded-lg p-6 hover:border-indigo-500 transition-colors bg-white shadow-sm">
            <div className="flex justify-between items-start mb-3">
              <div>
                <h3 className="font-extrabold text-xl text-indigo-900">{uni.program}</h3>
                <p className="text-slate-800 font-bold text-lg mt-1">{uni.university} <span className="text-slate-400 mx-1">•</span> {uni.location}</p>
                {uni.ranking && (
                    <span className="inline-block mt-1 text-xs font-bold bg-amber-100 text-amber-800 px-2 py-1 rounded border border-amber-200">
                        {uni.ranking}
                    </span>
                )}
              </div>
              <span className="bg-emerald-100 text-emerald-800 text-sm font-bold px-3 py-1 rounded border border-emerald-200 uppercase whitespace-nowrap">
                {uni.tuition || "Tuition Free"}
              </span>
            </div>
            
            <div className="bg-slate-50 p-4 rounded border border-slate-200 text-slate-800 mb-4">
               <strong className="text-black block mb-1">Agent Reasoning:</strong> 
               <span className="leading-relaxed">{uni.ncReasoning}</span>
            </div>

            {uni.url && (
              <a href={uni.url} target="_blank" rel="noreferrer" className="inline-flex items-center text-indigo-700 hover:text-indigo-900 font-bold underline decoration-2 underline-offset-2">
                View Official Program <ExternalLink className="w-4 h-4 ml-1" />
              </a>
            )}
          </div>
        ))}

        {results.length > 0 && (
            <div className="flex justify-end pt-4">
                 <button onClick={onNext} className="flex items-center text-slate-600 hover:text-indigo-700 font-bold">
                    Already have an offer? Validate it <ArrowRight className="w-5 h-5 ml-1" />
                 </button>
            </div>
        )}
      </div>
    </div>
  );
};