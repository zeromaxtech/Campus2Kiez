import React, { useState } from 'react';
import { Home, Map, Loader2, DollarSign, Train, Search } from 'lucide-react';
import { searchHousing } from '../services/geminiService';
import { HousingResult } from '../types';

interface HousingAgentProps {
  // 
}

export const HousingAgent: React.FC<HousingAgentProps> = () => {
  const [city, setCity] = useState('');
  const [university, setUniversity] = useState('');
  const [district, setDistrict] = useState('');
  const [rent, setRent] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<HousingResult | null>(null);

  const handleSearch = async () => {
    if (!city || !university) return;
    setLoading(true);
    try {
      const data = await searchHousing(university, city, district, rent);
      setResult(data);
    } catch (e) {
      console.error(e);
      alert("Housing search failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 animate-fade-in">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Housing Agent</h2>
        <p className="text-slate-600">
          Scout for WG rooms (shared apartments) or analyze a specific room's commute and price.
        </p>
      </div>

      <div className="space-y-4 mb-6">
        <div className="flex flex-col md:flex-row gap-4">
            <input 
                type="text" 
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="flex-1 px-4 py-3 rounded-lg border border-slate-300 bg-white text-black font-semibold focus:ring-2 focus:ring-indigo-500 outline-none placeholder-slate-500"
                placeholder="City (e.g. Berlin)"
            />
            <input 
                type="text" 
                value={university}
                onChange={(e) => setUniversity(e.target.value)}
                className="flex-1 px-4 py-3 rounded-lg border border-slate-300 bg-white text-black font-semibold focus:ring-2 focus:ring-indigo-500 outline-none placeholder-slate-500"
                placeholder="University (e.g. TU Berlin)"
            />
        </div>
        
        <div className="flex flex-col md:flex-row gap-4">
             <input 
                type="text" 
                value={district}
                onChange={(e) => setDistrict(e.target.value)}
                className="flex-1 px-4 py-3 rounded-lg border border-slate-300 bg-white text-black font-semibold focus:ring-2 focus:ring-indigo-500 outline-none placeholder-slate-500"
                placeholder="Specific District (Opt) e.g. Spandau"
            />
             <input 
                type="text" 
                value={rent}
                onChange={(e) => setRent(e.target.value)}
                className="flex-1 px-4 py-3 rounded-lg border border-slate-300 bg-white text-black font-semibold focus:ring-2 focus:ring-indigo-500 outline-none placeholder-slate-500"
                placeholder="Monthly Rent (Opt) e.g. 550"
            />
        </div>

        <button
            onClick={handleSearch}
            disabled={!city || !university || loading}
            className="w-full bg-indigo-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-indigo-700 disabled:bg-slate-300 transition-colors flex justify-center items-center"
        >
            {loading ? <Loader2 className="animate-spin mr-2" /> : <Search className="mr-2" />}
            {district ? "Analyze Commute & Value" : "Find Housing Hotspots"}
        </button>
      </div>

      {result && (
        <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-indigo-50 p-4 rounded-lg border border-indigo-100">
                    <div className="flex items-center text-indigo-900 font-bold mb-2">
                        <Map className="w-5 h-5 mr-2" /> {district ? "Location Analysis" : "Recommended Districts"}
                    </div>
                    <p className="text-indigo-800">{result.location}</p>
                </div>
                <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-100">
                    <div className="flex items-center text-emerald-900 font-bold mb-2">
                        <DollarSign className="w-5 h-5 mr-2" /> {district ? "Value Verdict" : "Price Estimate"}
                    </div>
                    <p className="text-emerald-800">{result.priceEstimate}</p>
                </div>
            </div>

            <div className="bg-slate-50 p-5 rounded-lg border border-slate-200">
                <div className="flex items-center text-slate-900 font-bold mb-3">
                    <Train className="w-5 h-5 mr-2 text-slate-600" />
                    Commute Analysis (Thought Signature)
                </div>
                <p className="text-slate-700 leading-relaxed text-sm">
                    {result.commuteAnalysis}
                </p>
            </div>

            {result.sources.length > 0 && (
                <div className="text-xs text-slate-400">
                    <span className="font-semibold mr-2">Sources:</span>
                    {result.sources.map((s, i) => (
                        <a key={i} href={s.uri} target="_blank" rel="noreferrer" className="hover:text-indigo-500 mr-2 underline">
                            {s.title}
                        </a>
                    ))}
                </div>
            )}
        </div>
      )}
    </div>
  );
};