import React, { useState } from 'react';
import { CheckSquare, Square, Info, ExternalLink, ArrowRight } from 'lucide-react';

interface APSTrackerProps {
  passportLast4: string;
  onComplete: () => void;
}

export const APSTracker: React.FC<APSTrackerProps> = ({ passportLast4, onComplete }) => {
  const [tasks, setTasks] = useState([
    { id: 1, text: "Register on APS India website", done: false, link: "https://www.aps-india.de/" },
    { id: 2, text: "Pay processing fee (approx. 18,000 INR)", done: false, hint: "Keep the receipt safe!" },
    { id: 3, text: "Send documents via courier", done: false, hint: "Include printed application form" },
    { id: 4, text: "Receive APS Certificate", done: false, hint: "Usually takes 4-6 weeks" },
    { id: 5, text: "Open Blocked Account (Expatrio)", done: false, link: "https://www.expatrio.com/" },
    { id: 6, text: "Get Health Insurance", done: false },
    { id: 7, text: "Apply for Student Visa (VFS)", done: false },
  ]);

  const toggleTask = (id: number) => {
    setTasks(tasks.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  const progress = Math.round((tasks.filter(t => t.done).length / tasks.length) * 100);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 animate-fade-in">
      <div className="mb-8 flex justify-between items-end">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Step 2: APS & Visa Navigator</h2>
          <p className="text-slate-600">Track your progress from India to Germany.</p>
        </div>
        <div className="text-right">
            <span className="text-3xl font-bold text-indigo-600">{progress}%</span>
            <span className="text-xs text-slate-400 block uppercase tracking-wider">Complete</span>
        </div>
      </div>

      <div className="w-full bg-slate-100 rounded-full h-2.5 mb-8">
        <div 
          className="bg-indigo-600 h-2.5 rounded-full transition-all duration-500 ease-out" 
          style={{ width: `${progress}%` }}
        ></div>
      </div>

      <div className="space-y-3">
        {tasks.map((task) => (
          <div 
            key={task.id}
            onClick={() => toggleTask(task.id)}
            className={`flex items-start p-4 rounded-lg border transition-all cursor-pointer group ${
              task.done ? 'bg-indigo-50 border-indigo-200' : 'bg-white border-slate-200 hover:border-indigo-300'
            }`}
          >
            <div className="mt-0.5 mr-3 text-indigo-600">
              {task.done ? <CheckSquare className="w-5 h-5" /> : <Square className="w-5 h-5 text-slate-400 group-hover:text-indigo-400" />}
            </div>
            <div className="flex-1">
              <div className={`font-medium ${task.done ? 'text-indigo-900 line-through decoration-indigo-300' : 'text-slate-800'}`}>
                {task.text}
              </div>
              {task.hint && (
                <div className="text-xs text-slate-500 mt-1 flex items-center">
                    <Info className="w-3 h-3 mr-1" /> {task.hint}
                </div>
              )}
            </div>
            {task.link && (
                <a 
                    href={task.link} 
                    target="_blank" 
                    rel="noreferrer"
                    onClick={(e) => e.stopPropagation()} 
                    className="ml-2 p-1 text-slate-400 hover:text-indigo-600"
                >
                    <ExternalLink className="w-4 h-4" />
                </a>
            )}
          </div>
        ))}
      </div>

      <div className="mt-8 flex justify-end">
          <button 
            onClick={onComplete}
            disabled={progress < 100}
            className={`px-6 py-3 rounded-lg font-semibold flex items-center space-x-2 transition-all ${
                progress === 100 
                ? 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md' 
                : 'bg-slate-100 text-slate-400 cursor-not-allowed'
            }`}
          >
              <span>Ready for Housing</span>
              <ArrowRight className="w-5 h-5" />
          </button>
      </div>
    </div>
  );
};