import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, Lock } from 'lucide-react';

interface LoginPageProps {
  onLogin: (email: string, passportLast4: string) => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passportLast4, setPassportLast4] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email && password && passportLast4.length === 4) {
      onLogin(email, passportLast4);
    } else {
      alert("Please fill in all fields correctly.");
    }
  };

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden">
        <div className="bg-indigo-600 p-8 text-center">
          <ShieldCheck className="w-16 h-16 text-white mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-white">Campus2Kiez</h1>
          <p className="text-indigo-200 mt-2">Secure Student Relocation Portal</p>
        </div>
        
        <div className="p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Gmail ID</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none"
                placeholder="student@gmail.com"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Password</label>
              <div className="relative">
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none"
                  placeholder="••••••••"
                  required
                />
                <Lock className="absolute right-3 top-3.5 w-5 h-5 text-slate-400" />
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">Passport (Last 4 Digits)</label>
              <input
                type="text"
                maxLength={4}
                value={passportLast4}
                onChange={(e) => setPassportLast4(e.target.value.replace(/\D/g,''))}
                className="w-full px-4 py-3 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none font-mono tracking-widest text-center text-lg"
                placeholder="XXXX"
                required
              />
              <p className="text-xs text-slate-500 mt-1 text-center">Used for secure file storage encryption</p>
            </div>

            <button
              type="submit"
              className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold text-lg hover:bg-slate-800 transition-transform active:scale-[0.98] flex items-center justify-center"
            >
              Access Portal <ArrowRight className="ml-2 w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};