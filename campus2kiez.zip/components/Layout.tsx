import React from 'react';
import { BookOpen, FileCheck, Key, Plane, ShieldCheck, MapPin, Search, Home, Radio } from 'lucide-react';
import { AppStep } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  currentStep: AppStep;
  setStep: (step: AppStep) => void;
}

export const Layout: React.FC<LayoutProps> = ({ children, currentStep, setStep }) => {
  const steps = [
    { id: AppStep.FIND_UNI, label: 'University Finder', icon: Search },
    { id: AppStep.VALIDATION, label: 'Verify Offer', icon: FileCheck },
    { id: AppStep.APS_VISA, label: 'APS & Visa', icon: Plane },
    { id: AppStep.HOUSING, label: 'Housing Agent', icon: Home },
    { id: AppStep.LIVE_AGENT, label: 'Live Translator', icon: Radio },
    { id: AppStep.VIDEO_KYC, label: 'Video KYC', icon: Key },
    { id: AppStep.ANMELDUNG, label: 'Anmeldung', icon: MapPin },
  ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-64 bg-slate-900 text-white flex-shrink-0">
        <div className="p-6 border-b border-slate-700 flex items-center space-x-3">
          <ShieldCheck className="w-8 h-8 text-indigo-400" />
          <div>
            <h1 className="text-xl font-bold tracking-tight">Campus2Kiez</h1>
            <p className="text-xs text-slate-400">Sovereign Agent</p>
          </div>
        </div>
        <nav className="p-4 space-y-2">
          {steps.map((step) => {
            const Icon = step.icon;
            const isActive = currentStep === step.id;
            return (
              <button
                key={step.id}
                onClick={() => setStep(step.id)}
                className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-lg'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="font-medium">{step.label}</span>
              </button>
            );
          })}
        </nav>
        <div className="p-6 mt-auto">
          <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
            <h4 className="text-xs font-semibold text-slate-400 uppercase mb-2">Agent Status</h4>
            <div className="flex items-center space-x-2">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
              <span className="text-sm text-emerald-400 font-medium">Monitoring</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 md:p-8 overflow-y-auto h-screen">
        <div className="max-w-4xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
};