import React, { useState } from 'react';
import { FileText, Database, Check, Loader2, Building, Upload } from 'lucide-react';
import { processRentalContract } from '../services/geminiService';
import { uploadFileToStorage } from '../services/firebase';
import { FunctionCallResponse } from '../types';

interface AnmeldungAssistantProps {
  passportLast4: string;
}

export const AnmeldungAssistant: React.FC<AnmeldungAssistantProps> = ({ passportLast4 }) => {
  const [file, setFile] = useState<File | null>(null);
  const [passportName, setPassportName] = useState('');
  const [passportNumber, setPassportNumber] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [submission, setSubmission] = useState<FunctionCallResponse | null>(null);
  const [status, setStatus] = useState<'idle' | 'uploading' | 'processing' | 'success' | 'error'>('idle');

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setSubmission(null);
      setStatus('idle');
    }
  };

  const handleProcess = async () => {
    if (!file || !passportName || !passportNumber) return;
    setLoading(true);
    
    try {
        // 1. Upload to Firebase
        setStatus('uploading');
        await uploadFileToStorage(file, passportLast4, 'anmeldung');

        // 2. Process with Gemini
        setStatus('processing');
        const toolCall = await processRentalContract(file);
        
        if (toolCall && toolCall.functionName === 'submit_anmeldung_request') {
          // Inject user provided passport details into the payload for completeness
          toolCall.args = { 
              ...toolCall.args, 
              passportNameVerified: passportName,
              passportNumberVerified: passportNumber 
          };
          setSubmission(toolCall);
          setStatus('success');
        } else {
          setStatus('error');
        }
    } catch (e) {
      console.error(e);
      setStatus('error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 animate-fade-in">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Step 4: Automated City Registration</h2>
        <p className="text-slate-600">
          Upload your "Wohnungsgeberbestätigung". We'll extract the data and submit your Anmeldung request automatically.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Input Section */}
        <div className="flex-1 space-y-4">
            <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Passport Name</label>
                <input 
                    type="text" 
                    value={passportName}
                    onChange={(e) => setPassportName(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="As per passport"
                />
            </div>
            <div>
                <label className="block text-xs font-bold text-slate-500 uppercase mb-1">Passport Number</label>
                <input 
                    type="text" 
                    value={passportNumber}
                    onChange={(e) => setPassportNumber(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border border-slate-300 focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="Enter full passport number"
                />
            </div>

            <div className="border-2 border-dashed border-slate-300 rounded-lg p-6 text-center hover:border-indigo-500 bg-slate-50 mt-4">
                <input type="file" id="contract-upload" className="hidden" onChange={handleFileChange} />
                <label htmlFor="contract-upload" className="cursor-pointer flex flex-col items-center">
                    <FileText className="w-10 h-10 text-slate-400 mb-3" />
                    <span className="font-medium text-slate-700">{file ? file.name : "Upload Rental Contract"}</span>
                </label>
            </div>

            <button
                onClick={handleProcess}
                disabled={!file || !passportName || !passportNumber || loading}
                className={`w-full py-3 rounded-lg font-semibold flex items-center justify-center space-x-2 transition-all ${
                    !file || !passportName || !passportNumber || loading
                    ? 'bg-slate-200 text-slate-500'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md'
                }`}
            >
                {loading ? <Loader2 className="animate-spin w-5 h-5" /> : <Database className="w-5 h-5" />}
                <span>Secure Upload & Submit</span>
            </button>
        </div>

        {/* Console / Output Section */}
        <div className="flex-1 bg-slate-900 rounded-lg p-6 font-mono text-sm text-slate-300 relative overflow-hidden">
             <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 to-purple-500"></div>
             
             <div className="mb-4 flex items-center text-slate-500 text-xs uppercase tracking-widest">
                <Building className="w-3 h-3 mr-2" />
                System Logs
             </div>

             <div className="space-y-2">
                 <div className="flex items-center">
                     <span className="text-green-500 mr-2">➜</span>
                     <span>Agent initialized for {passportLast4}</span>
                 </div>
                 {status === 'uploading' && (
                      <div className="flex items-center animate-pulse">
                         <span className="text-blue-500 mr-2">➜</span>
                         <span>Encrypting & Uploading to Vault...</span>
                     </div>
                 )}
                 {status === 'processing' && (
                     <div className="flex items-center animate-pulse">
                         <span className="text-yellow-500 mr-2">➜</span>
                         <span>Reading contract (OCR & Parsing)...</span>
                     </div>
                 )}
                 {status === 'success' && submission && (
                     <>
                        <div className="flex items-center">
                            <span className="text-green-500 mr-2">✓</span>
                            <span>Data extracted successfully.</span>
                        </div>
                        <div className="flex items-center text-blue-400">
                            <span className="text-blue-500 mr-2">➜</span>
                            <span>Executing tool: {submission.functionName}()</span>
                        </div>
                        <div className="mt-4 p-3 bg-slate-800 rounded border border-slate-700 text-xs">
                            <span className="text-slate-400 block mb-2">Payload:</span>
                            <pre className="text-green-300 overflow-x-auto">
                                {JSON.stringify(submission.args, null, 2)}
                            </pre>
                        </div>
                        <div className="mt-4 text-green-400 font-bold flex items-center">
                            <Check className="w-4 h-4 mr-2" />
                            REGISTRATION SUBMITTED
                        </div>
                     </>
                 )}
                 {status === 'error' && (
                      <div className="flex items-center text-red-400">
                        <span className="mr-2">✖</span>
                        <span>Failed to extract valid data or upload failed.</span>
                    </div>
                 )}
             </div>
        </div>
      </div>
    </div>
  );
};