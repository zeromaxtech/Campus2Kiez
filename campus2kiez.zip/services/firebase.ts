import { initializeApp } from "firebase/app";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

// TODO: Replace with your actual Firebase Configuration
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};

const app = initializeApp(firebaseConfig);
const storage = getStorage(app);

export type StorageFolder = 'passport' | 'video_kyc' | 'aps' | 'anmeldung' | 'offer_letter';

/**
 * Uploads a file to Firebase Storage with the structure:
 * Main / [PassportLast4] / [Folder] / [FileName]
 */
export const uploadFileToStorage = async (
  file: File | Blob, 
  passportLast4: string, 
  folder: StorageFolder,
  fileName?: string
): Promise<string> => {
  if (!passportLast4) throw new Error("Passport Last 4 digits required for storage");

  const name = fileName || (file as File).name || `capture_${Date.now()}.mp4`;
  const storagePath = `users/${passportLast4}/${folder}/${name}`;
  const storageRef = ref(storage, storagePath);

  try {
    const snapshot = await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(snapshot.ref);
    console.log(`Uploaded to ${storagePath}`);
    return downloadURL;
  } catch (error) {
    console.error("Firebase Upload Error:", error);
    // In a real app, throw error. For demo/mock without valid config, we return a mock URL
    return `https://mock-storage.com/${storagePath}`;
  }
};