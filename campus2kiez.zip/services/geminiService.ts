import { GoogleGenAI, Type, FunctionDeclaration } from "@google/genai";
import { VerificationResult, KYCResult, AnmeldungData, FunctionCallResponse, UniSearchResult, HousingResult } from "../types";

const apiKey = process.env.API_KEY;
if (!apiKey) {
  console.error("API_KEY is not defined in the environment.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || 'dummy-key' });

/**
 * Helper to convert File to base64
 */
export const fileToGenerativePart = async (file: File | Blob): Promise<{ inlineData: { data: string; mimeType: string } }> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const base64Data = reader.result as string;
      const base64Content = base64Data.split(',')[1];
      resolve({
        inlineData: {
          data: base64Content,
          mimeType: file.type || 'video/webm', // Fallback for blobs
        },
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
};

/**
 * Step 0: Find University (DAAD Agent)
 * Uses googleSearch to find programs and reason about NC and Budget.
 */
export const searchUniversities = async (field: string, gpa: string, ielts: string, preferredCity: string = ""): Promise<UniSearchResult[]> => {
  try {
    const prompt = `
      Search for Tuition-Free International Master programs in Germany for the field: "${field}".
      Profile: German Grade ${gpa} (Calculated from Indian CGPA), IELTS ${ielts}.
      ${preferredCity ? `Preferred Cities: ${preferredCity}.` : ''}
      
      Tasks:
      1. Use Google Search to find current English-taught programs on daad.de or university websites.
      2. Filter for "No Tuition Fees" (Semester contribution only).
      3. **Ranking Priority**: Sort the results by QS World University Rankings 2026 (e.g. TUM, LMU, Heidelberg, RWTH Aachen first).
      4. Analyze the "Numerus Clausus" (NC) or admission restrictions based on the provided German Grade (${gpa}).
      5. Budget Reasoning: For each city, reason if a student can survive on a €900/month budget (Rent + Living).
      
      Output JSON format:
      [
        {
          "university": "Name",
          "program": "Program Name",
          "location": "City",
          "ranking": "QS Rank 2026 (Approx)",
          "tuition": "Eur/Semester",
          "ncReasoning": "Analysis of admission chances (GPA) and Budget Feasibility (€900/mo) for this city.",
          "url": "Link to program"
        }
      ]
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: 'application/json',
      },
    });

    const text = response.text;
    if (!text) return [];
    
    // Parse JSON safely
    try {
        return JSON.parse(text) as UniSearchResult[];
    } catch (e) {
        console.error("Failed to parse search results", text);
        return [];
    }
  } catch (error) {
    console.error("Uni Search Error:", error);
    throw error;
  }
};

/**
 * Step 1: Validate Offer Letter AND Passport
 * Uses gemini-3-pro-preview to cross-reference documents.
 */
export const validateOfferLetter = async (offerFile: File, passportFile: File): Promise<VerificationResult> => {
  try {
    const offerPart = await fileToGenerativePart(offerFile);
    const passportPart = await fileToGenerativePart(passportFile);
    
    const prompt = `
      You are the Campus2Kiez Sovereign Agent. 
      Input 1: University Offer Letter.
      Input 2: Student Passport Copy.
      
      Tasks:
      1. Verify the University Offer Letter is legitimate (check logos, signatures, dates).
      2. Extract the Student Name from the Offer Letter.
      3. Extract the Student Name and Passport Number from the Passport Copy.
      4. Verify that the names match (allow for minor variations like middle names).
      5. Generate a unique 'studentHash' in the format: "Name-Last4Digits" (e.g., RahulKumar-1234). Use the name from the passport.
      
      Output JSON.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [offerPart, passportPart, { text: prompt }],
      },
      config: {
        thinkingConfig: { thinkingBudget: 4096 }, 
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isValid: { type: Type.BOOLEAN },
            universityName: { type: Type.STRING },
            studentName: { type: Type.STRING },
            passportNumber: { type: Type.STRING },
            studentHash: { type: Type.STRING, description: "Format: Name-Last4Digits" },
            reasoning: { type: Type.STRING },
          },
          required: ['isValid', 'universityName', 'studentName', 'studentHash', 'reasoning'],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    return JSON.parse(text) as VerificationResult;

  } catch (error) {
    console.error("Validation Error:", error);
    throw error;
  }
};

/**
 * Housing Agent
 * Uses googleSearch to find areas or analyze specific commute.
 */
export const searchHousing = async (university: string, city: string, district: string = "", rent: string = ""): Promise<HousingResult> => {
    try {
      const prompt = `
        Context: Student looking for housing in ${city} near ${university}.
        ${district && rent ? `Specific Scenario: Found a room in ${district} for ${rent}.` : ''}

        Tasks:
        1. Find/Analyze student housing areas.
        2. ${district ? `Calculate precise commute time from ${district} to ${university} using public transport. Assess feasibility for an 8 AM class.` : `Find districts with good commute to ${university}.`}
        3. ${district && rent ? `Verdict: Is ${rent} a good price for ${district}? Is the commute acceptable? Suggest "Book" or "Skip" in the reasoning.` : `Estimate average rent prices for WG rooms.`}
        
        Output JSON:
        {
            "location": "${district ? district : 'Recommended Districts'}",
            "priceEstimate": "${rent ? rent : 'Range in Eur'}",
            "commuteAnalysis": "Detailed reasoning on travel time, lines, and feasibility.",
            "sources": [] (Extracted from grounding chunks if possible, else empty)
        }
      `;
  
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
          responseMimeType: 'application/json',
        },
      });
  
      const text = response.text;
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      const sources = chunks.map((c: any) => ({ title: c.web?.title || 'Source', uri: c.web?.uri || '#' })).filter((s: any) => s.uri !== '#');

      let result = JSON.parse(text || '{}') as HousingResult;
      result.sources = sources;
      return result;
  
    } catch (error) {
      console.error("Housing Search Error:", error);
      throw error;
    }
  };

/**
 * Step 3: Video KYC + Optional Contract Verification
 * Uses gemini-2.5-flash-latest (multimodal) to analyze video and contract.
 */
export const analyzeVideoKYC = async (videoFile: File, contractFile?: File): Promise<KYCResult> => {
  try {
    const parts = [];
    parts.push(await fileToGenerativePart(videoFile));
    
    let prompt = `
      Analyze this video of a student arriving in Germany for a room handover.
      
      CRITICAL VALIDATION STEPS:
      1. **Passport Check**: Does the video clearly show a Passport Data page at any point? If yes, are details visible?
      2. **Key Handover**: Is there a physical exchange of keys (Metallschlüssel or Keycard) between two distinct individuals (Tenant and Landlord)?
      3. **Environment**: Does the background resemble a residential apartment hallway or entrance?
    `;

    if (contractFile) {
      parts.push(await fileToGenerativePart(contractFile));
      prompt += `
        \nAlso analyze the provided Rental Contract (Image/PDF).
        4. Extract the Landlord's Name from the contract.
        5. Verify if the contract looks like a standard German 'Wohnungsgeberbestätigung'.
      `;
    }

    prompt += `
      \nVerdict: verification is TRUE only if BOTH the Passport is shown AND Keys are exchanged.
      Return JSON.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-latest',
      contents: {
        parts: [...parts, { text: prompt }],
      },
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            verified: { type: Type.BOOLEAN, description: "True ONLY if Passport shown AND Keys exchanged." },
            keyExchanged: { type: Type.BOOLEAN },
            passportShown: { type: Type.BOOLEAN, description: "Is the passport document visible in the video?" },
            peopleCount: { type: Type.NUMBER },
            landlordName: { type: Type.STRING },
            contractAnalyzed: { type: Type.BOOLEAN },
            analysis: { type: Type.STRING, description: "Detailed observation of Passport details and Key exchange." },
          },
          required: ['verified', 'keyExchanged', 'peopleCount', 'analysis'],
        },
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from Gemini");
    return JSON.parse(text) as KYCResult;

  } catch (error) {
    console.error("KYC Error:", error);
    throw error;
  }
};

/**
 * Step 4: Anmeldung Automation
 * Parses Rental Contract (Wohnungsgeberbestätigung) and calls mock tool.
 */
export const processRentalContract = async (file: File): Promise<FunctionCallResponse | null> => {
  try {
    const filePart = await fileToGenerativePart(file);
    
    // Define the mock tool
    const submitAnmeldungTool: FunctionDeclaration = {
      name: 'submit_anmeldung_request',
      description: 'Submits the extracted data to the city registration office system.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          landlordName: { type: Type.STRING },
          moveInDate: { type: Type.STRING },
          address: { type: Type.STRING },
          tenantName: { type: Type.STRING },
          passportNameVerified: { type: Type.STRING },
          passportNumberVerified: { type: Type.STRING }
        },
        required: ['landlordName', 'moveInDate', 'address', 'tenantName'],
      },
    };

    const prompt = `
      You are the Campus2Kiez Agent. 
      Analyze this 'Wohnungsgeberbestätigung' (Landlord Confirmation).
      Extract the Landlord Name, Move-in Date (Einzugsdatum), Address of the dwelling, and the Tenant Name (Name der meldepflichtigen Person).
      
      If the document is valid and data is extracted, IMMEDIATELY call the 'submit_anmeldung_request' tool with the data.
      If data is missing or document is invalid, do not call the tool and instead explain why in text.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: {
        parts: [filePart, { text: prompt }],
      },
      config: {
        tools: [{ functionDeclarations: [submitAnmeldungTool] }],
        toolConfig: { functionCallingConfig: { mode: 'ANY' } }, // Force tool use if possible
        thinkingConfig: { thinkingBudget: 2048 },
      },
    });

    const functionCalls = response.functionCalls;
    if (functionCalls && functionCalls.length > 0) {
      const call = functionCalls[0];
      return {
        functionName: call.name,
        args: call.args,
      };
    }

    return null; // No tool called

  } catch (error) {
    console.error("Contract Processing Error:", error);
    throw error;
  }
};

/**
 * Live API Connection Helper
 */
export const createLiveSession = async (
    onOpen: () => void,
    onMessage: (msg: any) => void,
    onError: (e: any) => void,
    onClose: (e: any) => void
) => {
    return ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
            onopen: onOpen,
            onmessage: onMessage,
            onerror: onError,
            onclose: onClose
        },
        config: {
            systemInstruction: "You are a specialized live translator for a student in Germany. Your job is to translate between German and English (or Hindi) in real-time. If you hear German, translate to English. If you hear English or Hindi, translate to German. Keep translations concise and polite.",
            responseModalities: ["AUDIO"],
            speechConfig: {
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
            }
        }
    });
};